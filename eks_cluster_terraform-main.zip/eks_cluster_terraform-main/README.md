# Manage EKS cluster through Terraform config files
- Terraform IaC
- AWS EKS Cluster
- Jenkins CICD
- SonarQube
